﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOAP_WCF
{
    public class SoapGame
    {
        public string appID { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public string imgUrl { get; set; }
        public string releseDate { get; set; }
        public string reviewSummary { get; set; }
        public string price { get; set; }
    }
}
